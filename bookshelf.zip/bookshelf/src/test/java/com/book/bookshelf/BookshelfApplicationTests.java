package com.book.bookshelf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookshelfApplicationTests {

	@Test
	void contextLoads() {
	}

}
